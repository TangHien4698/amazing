<?php
    require_once PLUGIN_SERVER_PATH.'/admin/post-type/function-init.php';
    require_once PLUGIN_SERVER_PATH.'/admin/vc-extension/vc-init.php';
    require_once PLUGIN_SERVER_PATH.'/admin/shortcode/function_shortcode.php';
    require_once PLUGIN_SERVER_PATH.'/admin/rate/rating-input.php';
    require_once PLUGIN_SERVER_PATH.'/admin/rate/rating-output.php';
    /*
    * Required: widget recent post
    */
    require_once PLUGIN_SERVER_PATH . '/admin/widgets/recent-post.php';

    /*
    * Required: widget social
    */
    require_once PLUGIN_SERVER_PATH . '/admin/widgets/social.php';
?>