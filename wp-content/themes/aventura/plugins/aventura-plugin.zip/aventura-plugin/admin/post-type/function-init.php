<?php

$dir_pt = dirname( __FILE__ );
require_once $dir_pt . '/tour-post-type.php';
require_once $dir_pt . '/destination-post-type.php';
require_once $dir_pt . '/tour-guide-post-type.php';
require_once $dir_pt . '/branchs-post-type.php';
?>