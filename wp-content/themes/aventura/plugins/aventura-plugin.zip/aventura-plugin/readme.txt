30.05.2018
- Next Version 1.3.0
    + Update element Feature Tour.

10.04.2018
- Next Version 1.2.9
    + Fix issue search field duration in home page don't work.

28.03.2018
- Next Version 1.2.8
    + Update option orderby and order for element Feature Tour.

03.01.2018
- Next Version 1.2.7
    + Fix issue class rating tour.

03.01.2018
- Next Version 1.2.6
    + Fix issue about translate.
    + Update option select time and select combo for element Feature tour.

11.11.2017
- Next Version 1.2.5
    + Update background gradient for element Row.
    + Update file language

30.10.2017
- Next Version 1.2.3
    + Add options Currency ( symbol and position ) for price in elements ( Featured Tour, Latest tour, Tour Kind, Banner Slider ).

17.10.2017
- Next Version 1.2
    + Update type 5 for element Destinations.
    + Update type 4 and type 5 for element Feature Tour.
    + New element Latest Posts.

25.09.2017
- Next Version 1.1.1
    + Update element Destination.
    + Update size default "large" for option Image Size ( elelement Destination,Featuread Tour,Articles,Latest Tour ).

22.09.2017
- Next Version 1.1
    + Add Design Options, Extra class name for All Elements.
    + Add Limit Items for Element Latest Tour,Testimonials,Featured Tour.
    + Add Slide Options for Elements(Destination,Featured Tour,Latest Tour,Banner Slider,Customer,Testimonials).
    + Add Image Size for Element(Destination,Featuread Tour,Articles,Latest Tour).
    + Add Label Link for Element(Destination,Featuread Tour,Articles).
    + Fix Date Featured Tour.
    + Update icon service in Element Servicer.

19.09.2017
- Version 1.0